function paginateUsers(users, page) {
    // 0 - 1, página 1
    // 2 - 3, página 2
    // 4 - 5, página 3
    // 6 - 7, página 4
    // 8 - 9, página 5

    // 2 * (pagina - 1)
    // 2 * (pagina - 1) + 1
}


const u = [
    { name: 'Daniela', email: 'daniela@academlo.com', },
    { name: 'Juan', email: 'juan@academlo.com', },
    { name: 'Luis', email: 'luis@academlo.com', },
    { name: 'Pedro', email: 'pedro@academlo.com', },
    { name: 'Erik', email: 'luis@academlo.com', },
    { name: 'Georg', email: 'pedro@academlo.com', }
];

paginateUsers(u, 2);

// https://tasks-crud.academlo.com/api/auth/login
